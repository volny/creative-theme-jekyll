# Note

Copy the ```attacker_vm``` folder to the Attacker VM
Copy the ```user_vm folder``` to the User VM (i.e., the IoT VM)


